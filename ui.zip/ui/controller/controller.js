app.controller('testController', function($scope, $http) {

 $scope.addSkills = {
  "id" : "",
  "name": "",
  "status": null
 }
 $scope.model = {};
 $scope.model.searchSkill = "";

  $http.get('http://localhost:3000/api/').then(function(res) {
      $scope.skillList = res.data;
      $scope.showAdd = false;
    }, 
    function(err){   
      $scope.skillList = [];
      console.log(err);
  });

  $scope.addSkill = function() {
    $http
    .post('http://localhost:3000/api/skills', { name: $scope.addSkills.name, status: $scope.addSkills.status })
    .then(function(res) {
        if(res.data.success == true){
            $scope.skillList = res.data.data;
            $scope.showAdd = false;
        }
        $scope.addSkills = {};
      
    });
  }

  $scope.search = function(){
    $http
    .get('http://localhost:3000/api/search', { params : { search : $scope.model.searchSkill } }).then(function(res){
      if(res.data.length > 0){
        $scope.skillList = res.data;
        $scope.showAdd = false; 
      }
    });
  }

  $scope.changeSkill = function(index) {
    $scope.data = $scope.skillList[index];
    $http
      .put('http://localhost:3000/api/skills/'+ $scope.data.id +'/update', { name: $scope.data.name })
      .then(function(res) {
        if(res.data.success == true){       
          alert('Skill updated Successfully');
        }
      });
    $scope.openEdit = false;
  }


  //Change Statuys

  $scope.changeStatus = function(index, status){
    $scope.data = $scope.skillList[index];
    $http
      .put('http://localhost:3000/api/skills/'+ $scope.data.id +'/approve', { status: status })
      .then(function(res) {
        if(res.data.success == true){        
          alert('This skill is ' + (status === 1 ? 'Approved' : 'Rejected'));
        }
      });   
  }

});

/***************************************************************************************

            Please refer below angular code for calling apis

***************************************************************************************/

/*

   $http.get('/api/skills').then(function(res) {
    
        Must return below array of json
        *******************************************************
          Sample JSON
        *******************************************************  
        [{
          "id": "",
          "name": "",
          "status": null   //for approval (0 or 1)
        }]

    
    $scope.skillList = res.data; 
 });



  //Add 
  $scope.add = function() {
   $http
    .post('/api/skills', { name: $scope.data.name, status: $scope.data.status })
    .then(function(res) {
      alert('Skill added successfully!');
    });
  }

  Edit

  $scope.edit = function(index) {
    $scope.data = $scope.skillList[index];
    $http
      .put('/api/skills/'+ id +'/update', { name: $scope.data.name })
      .then(function(res) {
        alert('Skill updated Successfully');
      });
    $scope.openEdit = false;
  }


  //Change Statuys

  $scope.status = function(index, status){
    //Approve 
    $http
      .put('/api/skills/'+ id +'/approve', { status: status })
      .then(function(res) {
        alert('This skill is ' + (status === 1 ? 'Approved' : 'Rejected'));
      });   
  }

*/